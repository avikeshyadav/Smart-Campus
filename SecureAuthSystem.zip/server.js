require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const authRoutes = require('./routes/authRoutes');
const { generalLimiter } = require('./middleware/rateLimiter');

const app = express();

// ---------- Security middlewares ----------
app.use(helmet()); // secure HTTP headers
app.use(
  cors({
    origin: process.env.CLIENT_URL,
    credentials: true, // cookies allow karne ke liye
  })
);
app.use(express.json({ limit: '10kb' })); // body size limit - DoS se bachne ke liye
app.use(cookieParser());
app.use(generalLimiter);

// Agar app kisi reverse proxy (nginx, etc.) ke peeche hai to real client IP ke liye
app.set('trust proxy', 1);

// ---------- Routes ----------
app.use('/api/auth', authRoutes);

app.get('/', (req, res) => {
  res.json({ success: true, message: 'Secure Login System API chal raha hai' });
});

// ---------- 404 handler ----------
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route nahi mila' });
});

// ---------- Global error handler ----------
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Kuch galat ho gaya' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server chal raha hai http://localhost:${PORT} par`);
});
