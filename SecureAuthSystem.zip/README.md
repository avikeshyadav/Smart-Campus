# 🔐 Secure Login System (Node.js + MySQL)

Ek production-grade advanced secure authentication system, jisme yeh features implement kiye gaye hain:

## ✨ Features

| Feature | Details |
|---|---|
| **Password Hashing** | `bcrypt` (salted, 12 rounds, adaptive) |
| **JWT Tokens** | Short-lived access token (15m) + long-lived refresh token (7d) |
| **Token Rotation** | Refresh token har use par revoke + naya issue hota hai (replay-attack safe) |
| **Cross Verification** | Refresh tokens DB me hashed store hote hain; device info + IP track hota hai |
| **Email Verification** | Signup ke baad secure token-based email verification |
| **Password Reset** | Secure, time-limited (15 min) reset token flow |
| **Account Lockout** | 5 failed attempts ke baad 15 min ke liye account lock |
| **2FA (TOTP)** | Google Authenticator jaisa app-based 2FA (speakeasy + QR code) |
| **Rate Limiting** | Auth endpoints par brute-force protection |
| **Input Validation** | `express-validator` se strict validation |
| **Security Headers** | `helmet` middleware |
| **HttpOnly Cookies** | Refresh token cookie me `httpOnly`, `secure`, `sameSite: strict` |
| **Audit Log** | `login_history` table me har login attempt (success/fail) record hota hai |

## 📁 Project Structure

```
secure-login-system/
├── config/db.js              # MySQL connection pool
├── controllers/authController.js
├── routes/authRoutes.js
├── middleware/
│   ├── auth.js                # JWT verification middleware
│   ├── rateLimiter.js         # Brute-force protection
│   └── validate.js            # Input validation rules
├── utils/
│   ├── hash.js                 # bcrypt + secure token helpers
│   ├── token.js                 # JWT generate/verify
│   └── email.js                  # Nodemailer email sending
├── db/schema.sql                  # MySQL table definitions
├── server.js                       # App entry point
└── .env.example
```

## 🚀 Setup

```bash
# 1. Dependencies install karein
npm install

# 2. .env file banayein
cp .env.example .env
# .env me apni MySQL aur SMTP details bharein

# 3. Database setup karein
mysql -u root -p < db/schema.sql

# 4. Server run karein
npm run dev    # nodemon ke saath (development)
npm start       # production
```

## 📡 API Endpoints

### Public
- `POST /api/auth/register` — `{ name, email, password }`
- `GET  /api/auth/verify-email?token=...`
- `POST /api/auth/login` — `{ email, password, twoFactorCode? }`
- `POST /api/auth/refresh-token` — refresh cookie se naya access token
- `POST /api/auth/logout`
- `POST /api/auth/forgot-password` — `{ email }`
- `POST /api/auth/reset-password` — `{ token, newPassword }`

### Protected (`Authorization: Bearer <accessToken>`)
- `GET  /api/auth/profile`
- `POST /api/auth/2fa/setup` — QR code return karta hai
- `POST /api/auth/2fa/verify` — `{ token }` — 2FA enable karta hai

## 🔒 Security Notes (important)

1. `.env` file kabhi bhi git me commit mat karein — `.gitignore` me add karein.
2. Production me `JWT_ACCESS_SECRET` aur `JWT_REFRESH_SECRET` kam se kam 64 random characters ke hone chahiye.
3. HTTPS zaroor use karein (production me `secure: true` cookie flag activate hoga).
4. Raw refresh tokens kabhi DB me store nahi hote — sirf unka SHA-256 hash store hota hai.
5. Password policy: min 8 chars, 1 uppercase, 1 number, 1 special character (customize kar sakte hain `middleware/validate.js` me).

## 🧩 Optional Enhancements (agar aur mode features chahiye)

- Redis-backed rate limiting (multi-server deployments ke liye)
- OAuth login (Google/GitHub) — Passport.js se add ho sakta hai
- Device fingerprinting + "new device login" email alert
- CAPTCHA on repeated failed logins
- Refresh token family detection (agar revoked token dobara use ho to sab tokens revoke kar do — token-theft detection)
