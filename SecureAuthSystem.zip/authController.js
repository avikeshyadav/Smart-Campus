const pool = require('../config/db');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const { hashPassword, comparePassword, generateSecureToken, hashToken } = require('../utils/hash');
const { generateAccessToken, generateRefreshToken, verifyRefreshToken } = require('../utils/token');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../utils/email');

const MAX_ATTEMPTS = parseInt(process.env.MAX_LOGIN_ATTEMPTS || '5', 10);
const LOCK_MINUTES = parseInt(process.env.LOCK_TIME_MINUTES || '15', 10);

// ---------------- REGISTER ----------------
async function register(req, res) {
  const { name, email, password } = req.body;
  try {
    const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: 'Is email se account pehle se maujood hai' });
    }

    const passwordHash = await hashPassword(password);
    const verificationToken = generateSecureToken();
    const verificationExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    const [result] = await pool.query(
      `INSERT INTO users (name, email, password_hash, verification_token, verification_expires)
       VALUES (?, ?, ?, ?, ?)`,
      [name, email, passwordHash, hashToken(verificationToken), verificationExpires]
    );

    // Email bhejna best-effort hai - fail hone par bhi registration successful maana jaye
    try {
      await sendVerificationEmail(email, verificationToken);
    } catch (mailErr) {
      console.error('Verification email failed:', mailErr.message);
    }

    return res.status(201).json({
      success: true,
      message: 'Registration successful. Apna email verify karein.',
      userId: result.insertId,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

// ---------------- VERIFY EMAIL ----------------
async function verifyEmail(req, res) {
  const { token } = req.query;
  if (!token) return res.status(400).json({ success: false, message: 'Token missing' });

  try {
    const tokenHash = hashToken(token);
    const [rows] = await pool.query(
      'SELECT id FROM users WHERE verification_token = ? AND verification_expires > NOW()',
      [tokenHash]
    );

    if (rows.length === 0) {
      return res.status(400).json({ success: false, message: 'Token invalid ya expired hai' });
    }

    await pool.query(
      'UPDATE users SET is_verified = TRUE, verification_token = NULL, verification_expires = NULL WHERE id = ?',
      [rows[0].id]
    );

    return res.json({ success: true, message: 'Email verify ho gaya' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

// ---------------- LOGIN ----------------
async function login(req, res) {
  const { email, password, twoFactorCode } = req.body;
  const ip = req.ip;
  const userAgent = req.headers['user-agent'] || '';

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Email ya password galat hai' });
    }

    const user = rows[0];

    // Account lock check - brute force protection
    if (user.lock_until && new Date(user.lock_until) > new Date()) {
      const minutesLeft = Math.ceil((new Date(user.lock_until) - new Date()) / 60000);
      return res.status(423).json({
        success: false,
        message: `Account temporarily locked hai. ${minutesLeft} minute baad try karein.`,
      });
    }

    if (!user.is_verified) {
      return res.status(403).json({ success: false, message: 'Pehle apna email verify karein' });
    }

    const isMatch = await comparePassword(password, user.password_hash);
    if (!isMatch) {
      await handleFailedAttempt(user, ip, userAgent);
      return res.status(401).json({ success: false, message: 'Email ya password galat hai' });
    }

    // 2FA check - agar enabled hai to code verify karo
    if (user.two_fa_enabled) {
      if (!twoFactorCode) {
        return res.status(206).json({ success: false, requires2FA: true, message: '2FA code required hai' });
      }
      const verified = speakeasy.totp.verify({
        secret: user.two_fa_secret,
        encoding: 'base32',
        token: twoFactorCode,
        window: 1,
      });
      if (!verified) {
        await handleFailedAttempt(user, ip, userAgent);
        return res.status(401).json({ success: false, message: '2FA code galat hai' });
      }
    }

    // Successful login - reset failed attempts
    await pool.query('UPDATE users SET failed_attempts = 0, lock_until = NULL WHERE id = ?', [user.id]);
    await pool.query(
      'INSERT INTO login_history (user_id, ip_address, user_agent, status) VALUES (?, ?, ?, "SUCCESS")',
      [user.id, ip, userAgent]
    );

    const payload = { userId: user.id, email: user.email };
    const accessToken = generateAccessToken(payload);
    const refreshToken = generateRefreshToken(payload);
    const refreshExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    // Refresh token ko hash karke DB me store karo (device/IP cross-verification ke liye)
    await pool.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, device_info, ip_address, expires_at)
       VALUES (?, ?, ?, ?, ?)`,
      [user.id, hashToken(refreshToken), userAgent, ip, refreshExpiresAt]
    );

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.json({
      success: true,
      message: 'Login successful',
      accessToken,
      user: { id: user.id, name: user.name, email: user.email },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

async function handleFailedAttempt(user, ip, userAgent) {
  const attempts = user.failed_attempts + 1;
  let lockUntil = null;

  if (attempts >= MAX_ATTEMPTS) {
    lockUntil = new Date(Date.now() + LOCK_MINUTES * 60 * 1000);
  }

  await pool.query('UPDATE users SET failed_attempts = ?, lock_until = ? WHERE id = ?', [
    attempts,
    lockUntil,
    user.id,
  ]);

  await pool.query(
    'INSERT INTO login_history (user_id, ip_address, user_agent, status) VALUES (?, ?, ?, "FAILED")',
    [user.id, ip, userAgent]
  );
}

// ---------------- REFRESH TOKEN (cross verification) ----------------
async function refresh(req, res) {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ success: false, message: 'Refresh token missing' });

  try {
    const decoded = verifyRefreshToken(token);
    const tokenHash = hashToken(token);

    // DB me stored hash se cross-verify karo - ensure token revoke nahi hua aur expire nahi hua
    const [rows] = await pool.query(
      'SELECT * FROM refresh_tokens WHERE token_hash = ? AND user_id = ? AND is_revoked = FALSE AND expires_at > NOW()',
      [tokenHash, decoded.userId]
    );

    if (rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Refresh token invalid ya revoked hai' });
    }

    // Token rotation - purana revoke karke naya issue karo (replay attack se bachne ke liye)
    await pool.query('UPDATE refresh_tokens SET is_revoked = TRUE WHERE id = ?', [rows[0].id]);

    const payload = { userId: decoded.userId, email: decoded.email };
    const newAccessToken = generateAccessToken(payload);
    const newRefreshToken = generateRefreshToken(payload);
    const refreshExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await pool.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, device_info, ip_address, expires_at)
       VALUES (?, ?, ?, ?, ?)`,
      [decoded.userId, hashToken(newRefreshToken), req.headers['user-agent'], req.ip, refreshExpiresAt]
    );

    res.cookie('refreshToken', newRefreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.json({ success: true, accessToken: newAccessToken });
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Refresh token invalid ya expired hai' });
  }
}

// ---------------- LOGOUT ----------------
async function logout(req, res) {
  const token = req.cookies?.refreshToken;
  if (token) {
    await pool.query('UPDATE refresh_tokens SET is_revoked = TRUE WHERE token_hash = ?', [hashToken(token)]);
  }
  res.clearCookie('refreshToken');
  return res.json({ success: true, message: 'Logout successful' });
}

// ---------------- FORGOT PASSWORD ----------------
async function forgotPassword(req, res) {
  const { email } = req.body;
  try {
    const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    // User exist na ho tab bhi same message do - email enumeration se bachne ke liye
    if (rows.length === 0) {
      return res.json({ success: true, message: 'Agar account maujood hai to reset link bhej diya gaya hai' });
    }

    const resetToken = generateSecureToken();
    const resetExpires = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    await pool.query('UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?', [
      hashToken(resetToken),
      resetExpires,
      rows[0].id,
    ]);

    await sendPasswordResetEmail(email, resetToken);
    return res.json({ success: true, message: 'Agar account maujood hai to reset link bhej diya gaya hai' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

// ---------------- RESET PASSWORD ----------------
async function resetPassword(req, res) {
  const { token, newPassword } = req.body;
  try {
    const tokenHash = hashToken(token);
    const [rows] = await pool.query(
      'SELECT id FROM users WHERE reset_token = ? AND reset_expires > NOW()',
      [tokenHash]
    );

    if (rows.length === 0) {
      return res.status(400).json({ success: false, message: 'Token invalid ya expired hai' });
    }

    const newHash = await hashPassword(newPassword);
    await pool.query(
      'UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?',
      [newHash, rows[0].id]
    );

    // Password change hone par saare existing refresh tokens revoke karo - security best practice
    await pool.query('UPDATE refresh_tokens SET is_revoked = TRUE WHERE user_id = ?', [rows[0].id]);

    return res.json({ success: true, message: 'Password reset successful' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

// ---------------- 2FA SETUP ----------------
async function setup2FA(req, res) {
  try {
    const secret = speakeasy.generateSecret({ name: `SecureApp (${req.user.email})` });
    await pool.query('UPDATE users SET two_fa_secret = ? WHERE id = ?', [secret.base32, req.user.userId]);

    const qrImage = await qrcode.toDataURL(secret.otpauth_url);
    return res.json({ success: true, qrImage, secret: secret.base32 });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

async function verify2FA(req, res) {
  const { token } = req.body;
  try {
    const [rows] = await pool.query('SELECT two_fa_secret FROM users WHERE id = ?', [req.user.userId]);
    const verified = speakeasy.totp.verify({
      secret: rows[0].two_fa_secret,
      encoding: 'base32',
      token,
      window: 1,
    });

    if (!verified) {
      return res.status(400).json({ success: false, message: '2FA code galat hai' });
    }

    await pool.query('UPDATE users SET two_fa_enabled = TRUE WHERE id = ?', [req.user.userId]);
    return res.json({ success: true, message: '2FA enable ho gaya' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

// ---------------- PROFILE (protected route example) ----------------
async function getProfile(req, res) {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, email, is_verified, two_fa_enabled, created_at FROM users WHERE id = ?',
      [req.user.userId]
    );
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'User nahi mila' });
    return res.json({ success: true, user: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

module.exports = {
  register,
  verifyEmail,
  login,
  refresh,
  logout,
  forgotPassword,
  resetPassword,
  setup2FA,
  verify2FA,
  getProfile,
};
